import { Stack } from 'expo-router';

export default function InternetLayout() {
  return <Stack screenOptions={{ headerShown: false, animation: 'fade' }} />;
}
